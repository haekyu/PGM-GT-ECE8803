import numpy as np
import pickle


def variable_elimination(query, given, px0, pxi_x0, pxi_x1_4, verbose=False):
    num_mults = 0
    num_sums = 0
    term_pairs = {
        0: ({0}, px0.reshape(2,1,1,1,1,1,1,1,1,1,1,1)),
        1: ({0, 1}, pxi_x0[0].reshape(2,2,1,1,1,1,1,1,1,1,1,1)),
        2: ({0, 2}, pxi_x0[1].reshape(2,1,2,1,1,1,1,1,1,1,1,1)),
        3: ({0, 3}, pxi_x0[2].reshape(2,1,1,2,1,1,1,1,1,1,1,1)),
        4: ({0, 4}, pxi_x0[3].reshape(2,1,1,1,2,1,1,1,1,1,1,1)),
        5: ({1, 2, 3, 4, 5}, pxi_x1_4[0].reshape(1,2,2,2,2,2,1,1,1,1,1,1)),
        6: ({1, 2, 3, 4, 6}, pxi_x1_4[1].reshape(1,2,2,2,2,1,2,1,1,1,1,1)),
        7: ({1, 2, 3, 4, 7}, pxi_x1_4[2].reshape(1,2,2,2,2,1,1,2,1,1,1,1)),
        8: ({1, 2, 3, 4, 8}, pxi_x1_4[3].reshape(1,2,2,2,2,1,1,1,2,1,1,1)),
        9: ({1, 2, 3, 4, 9}, pxi_x1_4[4].reshape(1,2,2,2,2,1,1,1,1,2,1,1)),
        10: ({1, 2, 3, 4, 10}, pxi_x1_4[5].reshape(1,2,2,2,2,1,1,1,1,1,2,1)),
        11: ({1, 2, 3, 4, 11}, pxi_x1_4[6].reshape(1,2,2,2,2,1,1,1,1,1,1,2)),
    }
    # Identify summed vars
    summed_vars = set()
    for i in range(12):
        if (i not in query) and (i not in given.keys()):
            summed_vars.add(i)
            if verbose:
                print('Node {} will be summed'.format(i))

    # Prune leaf nodes
    removed_all_leaves = True
    for i in range(5, 12):
        if i in summed_vars:
            summed_vars.remove(i)
            term_pairs.pop(i)
            if verbose:
                print('Node {} was pruned'.format(i))
        else:
            removed_all_leaves = False
    if removed_all_leaves:
        for i in range(1, 5):
            if i in summed_vars:
                summed_vars.remove(i)
                term_pairs.pop(i)
                if verbose:
                    print('Node {} was pruned'.format(i))
    term_pairs = list(term_pairs.values())
    
    # Set the givens
    for i, val in given.items():
        k = 0
        while k < len(term_pairs):
            term_vars, _ = term_pairs[k]
            if i in term_vars:
                term_vars, term = term_pairs.pop(k)
                term_vars.remove(i)
                idx = [slice(None)] * 12
                idx[i] = [val]
                term = term[tuple(idx)]
                term_pairs.append((term_vars, term))
            else:
                k += 1

    while summed_vars:
        # Use minimum term size heuristic ordering
        best_factor_size = None
        best_var = None
        for i in summed_vars:
            other_vars = set()
            for term_vars, _ in term_pairs:
                if i in term_vars:
                    other_vars.update(term_vars)
            other_vars.remove(i)
            factor_size = len(other_vars)
            if (best_factor_size is None) or (best_factor_size > factor_size):
                best_factor_size = factor_size
                best_var = i
        if verbose:
            print('Summing over node {} b/c factor_size={}'.format(best_var, best_factor_size))
        # Perform the sum
        prod_term_vars = set()
        prod_term = None
        k = 0
        while k < len(term_pairs):
            term_vars, _ = term_pairs[k]
            if best_var in term_vars:
                term_vars, term = term_pairs.pop(k)
                prod_term_vars.update(term_vars)
                if prod_term is None:
                    prod_term = term
                else:
                    prod_term = prod_term * term
                    num_mults += prod_term.size
            else:
                k += 1
        prod_term_vars.remove(best_var)
        prod_term = np.sum(prod_term, axis=best_var, keepdims=True)
        num_sums += prod_term.size
        term_pairs.append((prod_term_vars, prod_term))
        summed_vars.remove(best_var)
    prod_term_vars, prod_term = term_pairs[0]
    for term_vars, term in term_pairs[1:]:
        prod_term_vars.update(term_vars)
        prod_term = prod_term * term
        num_mults += prod_term.size
    
    # Verification
    for i in query:
        assert i in prod_term_vars
    for i in prod_term_vars:
        assert i in query

    prod_term /= np.sum(prod_term)
    num_sums += prod_term.size - 1

    print('num_mults:', num_mults)
    print('num_sums:', num_sums)
    return prod_term

def brute_force(query, given, px0, pxi_x0, pxi_x1_4):
    def get_x_vec(num):
        x_vec = np.empty(12, dtype=np.uint8)
        for i in range(12):
            x_vec[i] = 0 != (num & (1 << i))
        return x_vec
    num_mults = 0
    num_sums = 0
    size = [1] * 12
    for i in query:
        size[i] = 2
    px = np.zeros(size)
    for num in range(4096):
        x = get_x_vec(num)
        flag = True
        for i, val in given.items():
            if val != x[i]:
                flag = False
                break
        if flag:
            temp = px0[x[0]]
            for i in range(4):
                temp *= pxi_x0[i, x[0], x[i+1]]
                num_mults += 1
            for i in range(7):
                temp *= pxi_x1_4[i, x[1], x[2], x[3], x[4], x[i+5]]
                num_mults += 1
            idx = [0] * 12
            for i in query:
                idx[i] = x[i]
            px[tuple(idx)] += temp
            num_sums += 1
    px /= np.sum(px)
    num_sums += px.size - 1

    print('num_mults:', num_mults)
    print('num_sums:', num_sums)
    return px


if __name__ == '__main__':
    q1_query = (1,)
    q1_given = {8: 1, 11: 1}
    q2_query = (7,8,9,10,11)
    q2_given = {4: 1}
    q3_query = (10,)
    q3_given = {0: 1}

    px0, pxi_x0, pxi_x1_4 = pickle.load(open('p8c_data.pkl', 'rb'))

    q1_probs = variable_elimination(q1_query, q1_given, px0, pxi_x0, pxi_x1_4)
    print(r'\begin{tabular}{c|c}')
    print(r'    Query 1 & $P(X_1 | X_8=1, X_{11}=1)$ \\')
    print(r'    \hline')
    for i1 in range(2):
        print('    $X_1={}$ & {} \\\\'.format(i1, np.round(q1_probs[:, i1].reshape(-1)[0], 4)))
    print(r'\end{tabular}')
    print(r'\\ \\')
    err = q1_probs - brute_force(q1_query, q1_given, px0, pxi_x0, pxi_x1_4)
#    print('max err:', np.max(np.abs(err)))

    q2_probs = variable_elimination(q2_query, q2_given, px0, pxi_x0, pxi_x1_4)
    print(r'\begin{tabular}{c|c}')
    print(r'    Query 2 & $P(X_7, X_8, X_9, X_{10}, X_{11} | X_4=1)$ \\')
    print(r'    \hline')
    for i7 in range(2):
        for i8 in range(2):
            for i9 in range(2):
                for i10 in range(2):
                    for i11 in range(2):
                        print('    $X_7={}, X_8={}, X_9={}, X_{{10}}={}, X_{{11}}={}$ & {} \\\\'.format(i7, i8, i9, i10, i11, np.round(q2_probs[..., i7, i8, i9, i10, i11].reshape(-1)[0], 4)))
    print(r'\end{tabular}')
    print(r'\\ \\')
    err = q2_probs - brute_force(q2_query, q2_given, px0, pxi_x0, pxi_x1_4)
#    print('max err:', np.max(np.abs(err)))

    q3_probs = variable_elimination(q3_query, q3_given, px0, pxi_x0, pxi_x1_4)
    print(r'\begin{tabular}{c|c}')
    print(r'    Query 3 & $P(X_{10} | X_0=1)$ \\')
    print(r'    \hline')
    for i10 in range(2):
        print('    $X_{{10}}={}$ & {} \\\\'.format(i10, np.round(q3_probs[..., i10, :].reshape(-1)[0], 4)))
    print(r'\end{tabular}')
    print(r'\\ \\')
    err = q3_probs - brute_force(q3_query, q3_given, px0, pxi_x0, pxi_x1_4)
#    print('max err:', np.max(np.abs(err)))
