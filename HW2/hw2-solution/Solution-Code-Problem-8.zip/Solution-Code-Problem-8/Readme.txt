p8c.py contains code for problem 8(c). You must provide the location to dataset.dat as argument 1. This must be run before p8d.py or p8e.py
p8d.py contains code for problem 8(d). You must provide the location to joint.dat as argument 1.
p8e.py contains code for problem 8(e).
